"""ZAP Transport Layer.

Provides transport abstractions for ZAP protocol communication.
Supports TCP, Unix sockets, Stdio, and HTTP/SSE.

Example:
    >>> from zap.transport import TcpTransport, connect
    >>>
    >>> transport = await connect("zap://localhost:9999")
    >>> await transport.send(b"hello")
    >>> response = await transport.recv()
"""

from __future__ import annotations

import abc
import asyncio
import struct
import sys
from typing import Any
from urllib.parse import urlparse, parse_qs

# ── Constants ────────────────────────────────────────────────────────────

FRAME_HEADER_SIZE = 4  # 4 bytes for length prefix
MAX_MESSAGE_SIZE = 16 * 1024 * 1024  # 16 MB
DEFAULT_PORT = 9999


# ── Errors ───────────────────────────────────────────────────────────────


class TransportError(Exception):
    """Transport-level error."""


# ── Transport Protocol ───────────────────────────────────────────────────


class Transport(abc.ABC):
    """Abstract transport for ZAP connections."""

    @abc.abstractmethod
    async def send(self, data: bytes) -> None:
        """Send a framed message."""

    @abc.abstractmethod
    async def recv(self) -> bytes:
        """Receive a framed message."""

    @abc.abstractmethod
    async def close(self) -> None:
        """Close the transport."""

    @abc.abstractmethod
    def is_connected(self) -> bool:
        """Check if transport is connected."""

    def local_addr(self) -> str | None:
        """Get local address if available."""
        return None

    def peer_addr(self) -> str | None:
        """Get peer address if available."""
        return None


# ── Framed Stream ────────────────────────────────────────────────────────


class _FramedStream:
    """Length-prefixed framing over asyncio streams."""

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self.reader = reader
        self.writer = writer

    async def send(self, data: bytes) -> None:
        if len(data) > MAX_MESSAGE_SIZE:
            raise TransportError(f"message too large: {len(data)}")
        # Write length prefix (big-endian u32)
        self.writer.write(struct.pack("!I", len(data)))
        self.writer.write(data)
        await self.writer.drain()

    async def recv(self) -> bytes:
        # Read length prefix
        len_buf = await self.reader.readexactly(FRAME_HEADER_SIZE)
        length = struct.unpack("!I", len_buf)[0]
        if length > MAX_MESSAGE_SIZE:
            raise TransportError(f"message too large: {length}")
        return await self.reader.readexactly(length)


# ── TCP Transport ────────────────────────────────────────────────────────


class TcpTransport(Transport):
    """TCP transport with length-prefixed framing."""

    def __init__(self, stream: _FramedStream, *, local: str | None = None, peer: str | None = None) -> None:
        self._stream: _FramedStream | None = stream
        self._local = local
        self._peer = peer

    @classmethod
    async def connect(cls, host: str, port: int) -> TcpTransport:
        """Connect to a TCP address."""
        reader, writer = await asyncio.open_connection(host, port)
        sock = writer.get_extra_info("socket")
        if sock is not None:
            sock.setsockopt(
                __import__("socket").IPPROTO_TCP,
                __import__("socket").TCP_NODELAY,
                1,
            )
        local = _format_sockname(writer.get_extra_info("sockname"))
        peer = f"{host}:{port}"
        return cls(_FramedStream(reader, writer), local=local, peer=peer)

    @classmethod
    def from_streams(
        cls,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> TcpTransport:
        """Create from existing asyncio streams (server-side)."""
        sock = writer.get_extra_info("socket")
        if sock is not None:
            sock.setsockopt(
                __import__("socket").IPPROTO_TCP,
                __import__("socket").TCP_NODELAY,
                1,
            )
        local = _format_sockname(writer.get_extra_info("sockname"))
        peer = _format_sockname(writer.get_extra_info("peername"))
        return cls(_FramedStream(reader, writer), local=local, peer=peer)

    async def send(self, data: bytes) -> None:
        if self._stream is None:
            raise TransportError("connection closed")
        await self._stream.send(data)

    async def recv(self) -> bytes:
        if self._stream is None:
            raise TransportError("connection closed")
        try:
            return await self._stream.recv()
        except (asyncio.IncompleteReadError, ConnectionError) as e:
            self._stream = None
            raise TransportError("connection closed") from e

    async def close(self) -> None:
        if self._stream is not None:
            self._stream.writer.close()
            try:
                await self._stream.writer.wait_closed()
            except Exception:
                pass
            self._stream = None

    def is_connected(self) -> bool:
        return self._stream is not None

    def local_addr(self) -> str | None:
        return self._local

    def peer_addr(self) -> str | None:
        return self._peer


class TcpTransportListener:
    """TCP listener for accepting ZAP connections."""

    def __init__(self, server: asyncio.AbstractServer, local: str) -> None:
        self._server = server
        self._local = local
        self._pending: asyncio.Queue[TcpTransport] = asyncio.Queue()

    @classmethod
    async def bind(cls, host: str, port: int) -> TcpTransportListener:
        """Bind to a TCP address and start listening."""
        listener = cls.__new__(cls)
        listener._pending = asyncio.Queue()

        async def on_connect(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
            transport = TcpTransport.from_streams(reader, writer)
            await listener._pending.put(transport)

        server = await asyncio.start_server(on_connect, host, port)
        addrs = server.sockets[0].getsockname() if server.sockets else (host, port)
        listener._server = server
        listener._local = f"{addrs[0]}:{addrs[1]}"
        return listener

    async def accept(self) -> TcpTransport:
        """Accept a new connection."""
        return await self._pending.get()

    async def close(self) -> None:
        """Close the listener."""
        self._server.close()
        await self._server.wait_closed()

    @property
    def local_addr(self) -> str:
        return self._local


# ── Unix Transport (Unix only) ───────────────────────────────────────────


if sys.platform != "win32":

    class UnixTransport(Transport):
        """Unix socket transport with length-prefixed framing."""

        def __init__(self, stream: _FramedStream, *, path: str | None = None) -> None:
            self._stream: _FramedStream | None = stream
            self._path = path

        @classmethod
        async def connect(cls, path: str) -> UnixTransport:
            """Connect to a Unix socket."""
            reader, writer = await asyncio.open_unix_connection(path)
            return cls(_FramedStream(reader, writer), path=path)

        @classmethod
        def from_streams(
            cls,
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
            *,
            path: str | None = None,
        ) -> UnixTransport:
            return cls(_FramedStream(reader, writer), path=path)

        async def send(self, data: bytes) -> None:
            if self._stream is None:
                raise TransportError("connection closed")
            await self._stream.send(data)

        async def recv(self) -> bytes:
            if self._stream is None:
                raise TransportError("connection closed")
            try:
                return await self._stream.recv()
            except (asyncio.IncompleteReadError, ConnectionError) as e:
                self._stream = None
                raise TransportError("connection closed") from e

        async def close(self) -> None:
            if self._stream is not None:
                self._stream.writer.close()
                try:
                    await self._stream.writer.wait_closed()
                except Exception:
                    pass
                self._stream = None

        def is_connected(self) -> bool:
            return self._stream is not None

        def local_addr(self) -> str | None:
            return f"unix://{self._path}" if self._path else None

        def peer_addr(self) -> str | None:
            return f"unix://{self._path}" if self._path else None

    class UnixTransportListener:
        """Unix socket listener for accepting ZAP connections."""

        def __init__(self, server: asyncio.AbstractServer, path: str) -> None:
            self._server = server
            self._path = path
            self._pending: asyncio.Queue[UnixTransport] = asyncio.Queue()

        @classmethod
        async def bind(cls, path: str) -> UnixTransportListener:
            """Bind to a Unix socket path."""
            import os

            # Remove existing socket file if present
            try:
                os.unlink(path)
            except FileNotFoundError:
                pass

            listener = cls.__new__(cls)
            listener._path = path
            listener._pending = asyncio.Queue()

            async def on_connect(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
                transport = UnixTransport.from_streams(reader, writer, path=path)
                await listener._pending.put(transport)

            server = await asyncio.start_unix_server(on_connect, path)
            listener._server = server
            return listener

        async def accept(self) -> UnixTransport:
            return await self._pending.get()

        async def close(self) -> None:
            self._server.close()
            await self._server.wait_closed()
            import os

            try:
                os.unlink(self._path)
            except FileNotFoundError:
                pass

        @property
        def local_addr(self) -> str:
            return self._path


# ── Stdio Transport ──────────────────────────────────────────────────────


class StdioTransport(Transport):
    """Stdio transport for subprocess MCP/ZAP servers.

    Spawns a subprocess and communicates via stdin/stdout with length-prefixed framing.
    """

    def __init__(
        self,
        process: asyncio.subprocess.Process,
        stream: _FramedStream,
        command: str,
    ) -> None:
        self._process: asyncio.subprocess.Process | None = process
        self._stream: _FramedStream | None = stream
        self._command = command

    @classmethod
    async def spawn(cls, command: str, args: list[str] | None = None) -> StdioTransport:
        """Spawn a subprocess with the given command and arguments."""
        proc = await asyncio.create_subprocess_exec(
            command,
            *(args or []),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=None,  # inherit
        )
        if proc.stdin is None or proc.stdout is None:
            raise TransportError("failed to capture stdio")

        # Wrap stdout as a StreamReader via _FramedStream
        # asyncio.subprocess already gives us StreamReader/WriteTransport
        reader = proc.stdout
        writer = proc.stdin

        # Create a lightweight adapter: proc.stdin is StreamWriter-like but not asyncio.StreamWriter.
        # We wrap it in _FramedStream manually.
        stream = _StdioFramedStream(reader, writer)
        return cls(proc, stream, command)  # type: ignore[arg-type]

    async def send(self, data: bytes) -> None:
        if self._stream is None:
            raise TransportError("stdin closed")
        await self._stream.send(data)

    async def recv(self) -> bytes:
        if self._stream is None:
            raise TransportError("process not running")
        try:
            return await self._stream.recv()
        except (asyncio.IncompleteReadError, ConnectionError) as e:
            self._stream = None
            raise TransportError("process exited") from e

    async def close(self) -> None:
        if self._process is not None:
            if self._process.stdin is not None:
                self._process.stdin.close()
            try:
                self._process.kill()
            except ProcessLookupError:
                pass
            await self._process.wait()
            self._process = None
            self._stream = None

    def is_connected(self) -> bool:
        return self._process is not None and self._process.returncode is None

    def local_addr(self) -> str | None:
        return f"stdio://{self._command}"

    def peer_addr(self) -> str | None:
        return f"stdio://{self._command}"


class _StdioFramedStream:
    """Length-prefixed framing over subprocess stdin/stdout."""

    def __init__(self, reader: asyncio.StreamReader, writer: Any) -> None:
        self.reader = reader
        self.writer = writer  # asyncio.subprocess stdin (WriteTransport)

    async def send(self, data: bytes) -> None:
        if len(data) > MAX_MESSAGE_SIZE:
            raise TransportError(f"message too large: {len(data)}")
        self.writer.write(struct.pack("!I", len(data)))
        self.writer.write(data)
        await self.writer.drain()

    async def recv(self) -> bytes:
        len_buf = await self.reader.readexactly(FRAME_HEADER_SIZE)
        length = struct.unpack("!I", len_buf)[0]
        if length > MAX_MESSAGE_SIZE:
            raise TransportError(f"message too large: {length}")
        return await self.reader.readexactly(length)


# ── HTTP/SSE Transport ───────────────────────────────────────────────────


class HttpSseTransport(Transport):
    """HTTP/SSE transport for remote MCP servers.

    Uses HTTP POST for sending and Server-Sent Events for receiving.
    """

    def __init__(self, base_url: str) -> None:
        import httpx

        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient()
        self._recv_queue: asyncio.Queue[bytes] = asyncio.Queue()
        self._connected = True
        self._sse_task: asyncio.Task[None] | None = None

    @classmethod
    async def connect(cls, base_url: str) -> HttpSseTransport:
        transport = cls(base_url)
        transport._sse_task = asyncio.create_task(transport._sse_listener())
        return transport

    async def _sse_listener(self) -> None:
        """Listen for Server-Sent Events."""
        import httpx

        url = f"{self._base_url}/sse"
        while self._connected:
            try:
                async with self._client.stream("GET", url) as resp:
                    event_data = ""
                    async for line_bytes in resp.aiter_lines():
                        if not self._connected:
                            return
                        line = line_bytes
                        if line.startswith("data: "):
                            event_data += line[6:]
                        elif line == "" and event_data:
                            await self._recv_queue.put(event_data.encode("utf-8"))
                            event_data = ""
            except (httpx.HTTPError, ConnectionError):
                if self._connected:
                    await asyncio.sleep(1)

    async def send(self, data: bytes) -> None:
        if not self._connected:
            raise TransportError("not connected")
        resp = await self._client.post(
            f"{self._base_url}/message",
            content=data,
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()

    async def recv(self) -> bytes:
        if not self._connected and self._recv_queue.empty():
            raise TransportError("not connected")
        return await self._recv_queue.get()

    async def close(self) -> None:
        self._connected = False
        if self._sse_task is not None:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except asyncio.CancelledError:
                pass
        await self._client.aclose()

    def is_connected(self) -> bool:
        return self._connected

    def peer_addr(self) -> str | None:
        return self._base_url


# ── URL Factory ──────────────────────────────────────────────────────────


async def connect(url: str) -> Transport:
    """Create a transport from a URL.

    Supported schemes:
    - ``zap://`` or ``tcp://`` — TCP transport
    - ``unix://`` — Unix socket transport (Unix only)
    - ``ws://`` or ``wss://`` — Reserved (not yet implemented)
    - ``stdio://`` — Stdio transport for subprocess servers
    - ``http://`` or ``https://`` — HTTP/SSE transport
    """
    parsed = urlparse(url)
    scheme = parsed.scheme

    if scheme in ("zap", "zap+tcp", "tcp"):
        host = parsed.hostname or "localhost"
        port = parsed.port or DEFAULT_PORT
        return await TcpTransport.connect(host, port)

    if scheme in ("zap+unix", "unix"):
        if sys.platform == "win32":
            raise TransportError("Unix sockets not supported on Windows")
        path = parsed.path
        return await UnixTransport.connect(path)  # type: ignore[possibly-undefined]

    if scheme == "stdio":
        command = parsed.path.lstrip("/")
        if not command:
            raise TransportError("stdio URL must specify command path")
        args = parse_qs(parsed.query).get("arg", [])
        return await StdioTransport.spawn(command, args)

    if scheme in ("http", "https"):
        return await HttpSseTransport.connect(url)

    if scheme in ("ws", "wss"):
        raise TransportError("WebSocket transport not yet implemented in Python — use TCP (zap://)")

    raise TransportError(f"unsupported URL scheme: {scheme}")


# ── Helpers ──────────────────────────────────────────────────────────────


def _format_sockname(addr: Any) -> str | None:
    if addr is None:
        return None
    if isinstance(addr, tuple) and len(addr) >= 2:
        return f"{addr[0]}:{addr[1]}"
    return str(addr)
