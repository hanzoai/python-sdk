"""ZAP Wire Protocol — encode/decode for the binary frame format.

Frame layout:
  [0x5A 0x41 0x50 0x01]  4 bytes  magic ("ZAP" + version 1)
  [type]                  1 byte   message type
  [length]                4 bytes  big-endian payload length
  [payload]               N bytes  UTF-8 JSON (Cap'n Proto in future)
"""

from __future__ import annotations

import json
import struct
from typing import Any

# ── Constants ───────────────────────────────────────────────────────────

ZAP_MAGIC = b"\x5a\x41\x50\x01"

MSG_HANDSHAKE = 0x01
MSG_HANDSHAKE_OK = 0x02
MSG_REQUEST = 0x10
MSG_RESPONSE = 0x11
MSG_STREAM = 0x20
MSG_PING = 0xFE
MSG_PONG = 0xFF

HEADER_SIZE = 9  # 4 (magic) + 1 (type) + 4 (length)
MAX_MESSAGE_SIZE = 16 * 1024 * 1024  # 16 MB

ZAP_PORTS = [9999, 9998, 9997, 9996, 9995]


# ── Encode / Decode ─────────────────────────────────────────────────────


def encode(msg_type: int, payload: Any) -> bytes:
    """Encode a ZAP frame: magic + type + length + JSON payload."""
    data = json.dumps(payload).encode("utf-8")
    header = ZAP_MAGIC + struct.pack("!BL", msg_type, len(data))
    return header + data


def decode(buf: bytes) -> tuple[int, Any] | None:
    """Decode a single ZAP frame.

    Returns (msg_type, payload) or None if the buffer is invalid.
    """
    if len(buf) < HEADER_SIZE:
        return None

    if buf[:4] != ZAP_MAGIC:
        return None

    msg_type = buf[4]
    length = struct.unpack("!L", buf[5:9])[0]

    if len(buf) < HEADER_SIZE + length:
        return None

    try:
        payload = json.loads(buf[HEADER_SIZE : HEADER_SIZE + length].decode("utf-8"))
        return (msg_type, payload)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
